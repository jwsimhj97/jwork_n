package com.dao;

public class Calculator {
	public static int process(int n) {
		return n * n * n;
	}
}
