package second;

public class Constructor {
	private int i;
	private String s;
	
	public Constructor(int i, String s) {
		this.i = i;
		this.s = s;
	}
	
	public void setI(int i) {
		this.i = i;		
	}
	public int getI() {
		return i;	
	}
	
	public void setS(String s) {
		this.s = s;
	}
	
	public String getS() {
		return s;
	}
}
